from socket import socket, AF_INET, SOCK_STREAM
import sys, os
from helpers import *

def extract():
    """() -> NoneType
    Opens the public key infrastructure server to extract RSA public keys.
    The public keys must have already been in the server's folder.
    """
    with socket(AF_INET, SOCK_STREAM) as sock:
        sock.bind((PKI_HOST, PKI_PORT))
        sock.listen()
        conn, addr = sock.accept()
        with conn:
            print('PKI: connection from address', addr)
            while True:
                # A, B --->  
                # <--- {K_PB, B}(K_PA)
                # WRITE YOUR CODE HERE!


if __name__ == "__main__":
    print("PKI: I am the Public Key Infrastructure Server!")
    print("PKI: listening for a key to be extracted")
    extract()
